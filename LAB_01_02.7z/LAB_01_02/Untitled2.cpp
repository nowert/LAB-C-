#include<windows.h>
LONG WINAPI WndProc(HWND,UINT,WPARAM,LPARAM);
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpszCmdLine,int nCmdShow)
{
WNDCLASS wc;
HWND hwnd;
MSG msg;
/***************** 1. Define Windows class **************************/
wc.style = 0; // Class style
wc.lpfnWndProc = (WNDPROC) WndProc; // Window procedure address
wc.cbClsExtra = 0; // Class extra bytes
wc.cbWndExtra = 0; // Window extra bytes
wc.hInstance = hInstance; // Instance handle
wc.hIcon = LoadIcon (NULL, IDI_WINLOGO); // Icon handle
wc.hCursor = LoadCursor (NULL, IDC_ARROW); // Cursor handle
wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1); // Background color
wc.lpszMenuName = NULL; // Menu name
wc.lpszClassName = "MyWndClass"; // WNDCLASS name

/***************** 2. Register the Windows class **********************/
RegisterClass(&wc);
/***************** 3. Create window **********************/
hwnd = CreateWindow (
"MyWndClass", // WNDCLASS name
"SDK Application", // Window title
WS_OVERLAPPEDWINDOW, // Window style
CW_USEDEFAULT, // Horizontal position
CW_USEDEFAULT, // Vertical position
CW_USEDEFAULT, // Initial width
CW_USEDEFAULT, // Initial height
HWND_DESKTOP, // Handle of parent window
NULL, // Menu handle
hInstance, // Application's instance handle
NULL // Window-creation data
);

/***************** 4. Display the window **********************/
ShowWindow (hwnd, nCmdShow);
UpdateWindow (hwnd);
/***************** 5. Message loop **********************/
while(GetMessage(&msg,NULL,0,0)){
	TranslateMessage(&msg);
	DispatchMessage(&msg);
}
return msg.wParam;
}
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam,LPARAM lParam)
{
PAINTSTRUCT ps;
HDC hdc;
switch(message){
	case WM_ENABLE:
	hdc = BeginPaint(hwnd,&ps);
	
	//*************************no.1****************************
		//kha
		
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Ellipse(hdc,115,190,345,400); 
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Rectangle(hdc, 100, 270,360, 400);
			
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Rectangle(hdc, 160, 280,225, 385);
		Rectangle(hdc, 230, 280,298, 385);
		Ellipse(hdc,150,190,310,350); 
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(66,143,232)));
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Rectangle(hdc, 161, 300,297,349);
		Rectangle(hdc, 290, 220,310, 240);
		Rectangle(hdc, 153, 220,180, 240);
		Rectangle(hdc, 170, 205,290, 220);
		Rectangle(hdc, 165, 215,295, 225);
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
		Ellipse(hdc,227,360,305,392);
		Ellipse(hdc,153,360,229,392);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		//thong
		Ellipse(hdc,160,330,300,195); //wi tong
		Ellipse(hdc,180,300,280,210); //wi tong
		Rectangle(hdc, 181, 260,279, 261);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		Rectangle(hdc, 180, 221,282, 260);
		
		LineTo(hdc, 163, 110);
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
		Ellipse(hdc,105,260,155,305);
		Ellipse(hdc,305,260,355,305);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		
		
	    //head	
	   
		Ellipse(hdc,125,210,335,30); // big h
	    SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Ellipse(hdc,125,209,335,30); // big h
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        Ellipse(hdc,145,210,315,70); //small h
		Ellipse(hdc,192,100,229,60); //ta
		Ellipse(hdc,231,100,266,60); //ta
		SelectObject(hdc,CreateSolidBrush(RGB(255,0,0)));
		Ellipse(hdc,219,118,239,98);  //jamug
		SelectObject(hdc,CreateSolidBrush(RGB(255,0,0)));
		Rectangle(hdc, 170, 195,289, 205); //pogkor
		Ellipse(hdc,167,195,174,205);  //jamug
		Ellipse(hdc,285,195,292,205);  //jamug
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,0,0)));
		Ellipse(hdc,168,195,175,205);  //jamug
		Ellipse(hdc,284,195,291,205);  //jamug
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Rectangle(hdc, 198, 205,262, 260);//******************************
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,0)));
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
        Ellipse(hdc,215,190,245,220);//kading
        Ellipse(hdc,213,197,247,205);
        Rectangle(hdc, 230, 205,231,220);
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
        Ellipse(hdc,225,206,235,214);
        SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
        SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
		Ellipse(hdc,207,85,220,70); // ta b r
		Ellipse(hdc,238,85,250,70); // ta b R
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Ellipse(hdc,170,145,290,170); // m
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		Ellipse(hdc,170,130,290,168); //w pagbon
		
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    Rectangle(hdc, 229, 118,230, 170); //s jamug
	    
	    
	    //nuad
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 218, 120);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 215, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 155, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 217, 141);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 160, 147);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 241, 120);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 300, 110);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 240, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 303, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 240, 140);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 297, 143);
	    
	    //*************************no.2****************************
	    //kha
		
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Ellipse(hdc,365,190,595,400); 
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Rectangle(hdc, 350, 270,610, 400);
			
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Rectangle(hdc, 410, 280,505, 385);
		Rectangle(hdc, 480, 280,548, 385);
		Ellipse(hdc,400,190,560,350); 
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(66,143,232)));
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Rectangle(hdc, 411, 300,547,349);
		Rectangle(hdc, 540, 220,560, 240);
		Rectangle(hdc, 403, 220,430, 240);
		Rectangle(hdc, 420, 205,540, 220);
		Rectangle(hdc, 415, 215,545, 225);
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
		Ellipse(hdc,477,360,555,392);
		Ellipse(hdc,403,360,479,392);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		//thong
		Ellipse(hdc,410,330,550,195); //wi tong
		Ellipse(hdc,430,300,530,210); //wi tong
		Rectangle(hdc, 431, 260,529, 261);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		Rectangle(hdc, 430, 221,532, 260);
		
		LineTo(hdc, 413, 110);
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
		Ellipse(hdc,355,260,405,305);
		Ellipse(hdc,555,260,605,305);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		
		
	    //head	
	   
		Ellipse(hdc,375,210,585,30); // big h
	    SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Ellipse(hdc,375,209,585,30); // big h
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        Ellipse(hdc,395,210,565,70); //small h
		Ellipse(hdc,445,100,479,60); //ta
		Ellipse(hdc,481,100,516,60); //ta
		SelectObject(hdc,CreateSolidBrush(RGB(255,0,0)));
		Ellipse(hdc,469,118,489,98);  //jamug
		SelectObject(hdc,CreateSolidBrush(RGB(255,0,0)));
		Rectangle(hdc, 420, 195,539, 205); //pogkor
		Ellipse(hdc,417,195,424,205);  //jamug
		Ellipse(hdc,535,195,542,205);  //jamug
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,0,0)));
		Ellipse(hdc,418,195,425,205);  //jamug
		Ellipse(hdc,534,195,541,205);  //jamug
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Rectangle(hdc, 448, 205,512, 260);//******************************
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,0)));
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
        Ellipse(hdc,465,190,495,220);//kading
        Ellipse(hdc,463,197,497,205);
        Rectangle(hdc, 480, 205,481,220);
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
        Ellipse(hdc,475,206,485,214);
        SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
        SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
		Ellipse(hdc,457,85,470,70); // ta b r
		Ellipse(hdc,488,85,500,70); // ta b R
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Ellipse(hdc,420,145,540,170); // m
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		Ellipse(hdc,420,130,540,168); //w pagbon
		
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    Rectangle(hdc, 479, 118,480, 170); //s jamug
	    
	    
	    //nuad
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 468, 120);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 465, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 405, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 467, 141);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 410, 147);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 491, 120);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 550, 110);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 490, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 553, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 490, 140);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 547, 143);
	    //*************************no.3****************************
	    //kha
		
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Ellipse(hdc,615,190,845,400); 
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Rectangle(hdc, 600, 270,860, 400);
			
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Rectangle(hdc, 660, 280,725, 385);
		Rectangle(hdc, 730, 280,798, 385);
		Ellipse(hdc,650,190,810,350); 
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(66,143,232)));
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Rectangle(hdc, 661, 300,797,349);
		Rectangle(hdc, 790, 220,810, 240);
		Rectangle(hdc, 653, 220,680, 240);
		Rectangle(hdc, 670, 205,790, 220);
		Rectangle(hdc, 665, 215,795, 225);
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
		Ellipse(hdc,727,360,805,392);
		Ellipse(hdc,653,360,729,392);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		//thong
		Ellipse(hdc,660,330,800,195); //wi tong
		Ellipse(hdc,680,300,780,210); //wi tong
		Rectangle(hdc, 681, 260,779, 261);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		Rectangle(hdc, 680, 221,782, 260);
		
		LineTo(hdc, 663, 110);
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
		Ellipse(hdc,605,260,655,305);
		Ellipse(hdc,805,260,855,305);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		
		
	    //head	
	   
		Ellipse(hdc,625,210,835,30); // big h
	    SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Ellipse(hdc,625,209,835,30); // big h
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        Ellipse(hdc,645,210,815,70); //small h
		Ellipse(hdc,692,100,729,60); //ta
		Ellipse(hdc,731,100,766,60); //ta
		SelectObject(hdc,CreateSolidBrush(RGB(255,0,0)));
		Ellipse(hdc,719,118,739,98);  //jamug
		SelectObject(hdc,CreateSolidBrush(RGB(255,0,0)));
		Rectangle(hdc, 670, 195,789, 205); //pogkor
		Ellipse(hdc,667,195,674,205);  //jamug
		Ellipse(hdc,785,195,792,205);  //jamug
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,0,0)));
		Ellipse(hdc,668,195,675,205);  //jamug
		Ellipse(hdc,784,195,791,205);  //jamug
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Rectangle(hdc, 698, 205,762, 260);//******************************
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,0)));
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
        Ellipse(hdc,715,190,745,220);//kading
        Ellipse(hdc,713,197,747,205);
        Rectangle(hdc, 730, 205,731,220);
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
        Ellipse(hdc,725,206,735,214);
        SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
        SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
		Ellipse(hdc,707,85,720,70); // ta b r
		Ellipse(hdc,738,85,750,70); // ta b R
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Ellipse(hdc,670,145,790,170); // m
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		Ellipse(hdc,670,130,790,168); //w pagbon
		
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    Rectangle(hdc, 729, 118,730, 170); //s jamug
	    
	    
	    //nuad
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 718, 120);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 715, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 655, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 717, 141);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 660, 147);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 741, 120);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 800, 110);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 740, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 803, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 740, 140);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 797, 143);
	     //*************************no.4****************************
	     	SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Ellipse(hdc,865,190,1095,400); 
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Rectangle(hdc, 850, 270,1110, 400);
			
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Rectangle(hdc, 910, 280,1005, 385);
		Rectangle(hdc, 980, 280,1048, 385);
		Ellipse(hdc,900,190,1060,350); 
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(66,143,232)));
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Rectangle(hdc, 911, 300,1047,349);
		Rectangle(hdc, 1040, 220,1060, 240);
		Rectangle(hdc, 903, 220,930, 240);
		Rectangle(hdc, 920, 205,1040, 220);
		Rectangle(hdc, 915, 215,1045, 225);
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
		Ellipse(hdc,977,360,1055,392);
		Ellipse(hdc,903,360,979,392);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		//thong
		Ellipse(hdc,910,330,1050,195); //wi tong
		Ellipse(hdc,930,300,1030,210); //wi tong
		Rectangle(hdc, 931, 260,1029, 261);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		Rectangle(hdc, 930, 221,1032, 260);
		
		LineTo(hdc, 913, 110);
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
		Ellipse(hdc,855,260,905,305);
		Ellipse(hdc,1055,260,1105,305);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		
		
	    //head	
	   
		Ellipse(hdc,875,210,1085,30); // big h
	    SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Ellipse(hdc,875,209,1085,30); // big h
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        Ellipse(hdc,895,210,1065,70); //small h
		Ellipse(hdc,945,100,979,60); //ta
		Ellipse(hdc,981,100,1016,60); //ta
		SelectObject(hdc,CreateSolidBrush(RGB(255,0,0)));
		Ellipse(hdc,969,118,989,98);  //jamug
		SelectObject(hdc,CreateSolidBrush(RGB(255,0,0)));
		Rectangle(hdc, 920, 195,1039, 205); //pogkor
		Ellipse(hdc,917,195,924,205);  //jamug
		Ellipse(hdc,1035,195,1042,205);  //jamug
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,0,0)));
		Ellipse(hdc,918,195,925,205);  //jamug
		Ellipse(hdc,1034,195,1041,205);  //jamug
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Rectangle(hdc, 948, 205,1012, 260);//******************************
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,0)));
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
        Ellipse(hdc,965,190,995,220);//kading
        Ellipse(hdc,963,197,997,205);
        Rectangle(hdc, 980, 205,981,220);
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
        Ellipse(hdc,975,206,985,214);
        SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
        SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
		Ellipse(hdc,957,85,970,70); // ta b r
		Ellipse(hdc,988,85,1000,70); // ta b R
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Ellipse(hdc,920,145,1040,170); // m
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		Ellipse(hdc,920,130,1040,168); //w pagbon
		
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    Rectangle(hdc, 979, 118,980, 170); //s jamug
	    
	    
	    //nuad
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 968, 120);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 965, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 905, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 967, 141);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 910, 147);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 991, 120);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 1050, 110);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 990, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 1053, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 990, 140);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 1047, 143);
	    
	  //*************************no.5**************************** 
	   //kha
		
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Ellipse(hdc,1115,190,1345,400); 
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Rectangle(hdc, 1100, 270,1360, 400);
			
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Rectangle(hdc, 1160, 280,1225, 385);
		Rectangle(hdc, 1230, 280,1298, 385);
		Ellipse(hdc,1150,190,1310,350); 
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(66,143,232)));
		SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Rectangle(hdc, 1161, 300,1297,349);
		Rectangle(hdc, 1290, 220,1310, 240);
		Rectangle(hdc, 1153, 220,1180, 240);
		Rectangle(hdc, 1170, 205,1290, 220);
		Rectangle(hdc, 1165, 215,1295, 225);
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
		Ellipse(hdc,1227,360,1305,392);
		Ellipse(hdc,1153,360,1229,392);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		//thong
		Ellipse(hdc,1160,330,1300,195); //wi tong
		Ellipse(hdc,1180,300,1280,210); //wi tong
		Rectangle(hdc, 1181, 260,1279, 261);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		Rectangle(hdc, 1180, 221,1282, 260);
		
		LineTo(hdc, 1163, 110);
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
		Ellipse(hdc,1105,260,1155,305);
		Ellipse(hdc,1305,260,1355,305);
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
		
		
	    //head	
	   
		Ellipse(hdc,1125,210,1335,30); // big h
	    SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
		Ellipse(hdc,1125,209,1335,30); // big h
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        Ellipse(hdc,1145,210,1315,70); //small h
		Ellipse(hdc,1192,100,1229,60); //ta
		Ellipse(hdc,1231,100,1266,60); //ta
		SelectObject(hdc,CreateSolidBrush(RGB(255,0,0)));
		Ellipse(hdc,1219,118,1239,98);  //jamug
		SelectObject(hdc,CreateSolidBrush(RGB(255,0,0)));
		Rectangle(hdc, 1170, 195,1289, 205); //pogkor
		Ellipse(hdc,1167,195,1174,205);  //jamug
		Ellipse(hdc,1285,195,1292,205);  //jamug
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,0,0)));
		Ellipse(hdc,1168,195,1175,205);  //jamug
		Ellipse(hdc,1284,195,1291,205);  //jamug
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Rectangle(hdc, 1198, 205,1262, 260);//******************************
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,0)));
		SelectObject(hdc,CreatePen(PS_SOLID,2,RGB(0,0,0)));
        Ellipse(hdc,1215,190,1245,220);//kading
        Ellipse(hdc,1213,197,1247,205);
        Rectangle(hdc, 1230, 205,1231,220);
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
        Ellipse(hdc,1225,206,1235,214);
        SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
        SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
        SelectObject(hdc,CreateSolidBrush(RGB(0,0,0)));
		Ellipse(hdc,1207,85,1220,70); // ta b r
		Ellipse(hdc,1238,85,1250,70); // ta b R
		SelectObject(hdc,CreateSolidBrush(RGB(255,255,255)));
		Ellipse(hdc,1170,145,1290,170); // m
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
		Ellipse(hdc,1170,130,1290,168); //w pagbon
		
		SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    Rectangle(hdc, 1229, 118,1230, 170); //s jamug
	    
	    
	    //nuad
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 1218, 120);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 1215, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 1155, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 1217, 141);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 1160, 147);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 1241, 120);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 1300, 110);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 1240, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 1303, 130);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(255,255,255)));
	    LineTo(hdc, 1240, 140);
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(0,0,0)));
	    LineTo(hdc, 1297, 143); 
	    
	    
	     SelectObject(hdc,CreateSolidBrush(RGB(66,143,232)));
	    SelectObject(hdc,CreatePen(PS_SOLID,1,RGB(66,143,232)));
	     Rectangle(hdc, 1065,130,1082,140);
	     Rectangle(hdc, 815,130,832,140);
	     Rectangle(hdc, 565,130,582,140);
	     Rectangle(hdc, 315,130,332,140);
	EndPaint(hwnd,&ps);
	return 0;
	case WM_DESTROY:
	PostQuitMessage(0);
	return 0;
}
return DefWindowProc (hwnd, message, wParam, lParam);
}

