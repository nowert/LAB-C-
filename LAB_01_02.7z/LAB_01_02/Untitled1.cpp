#include<windows.h>
LONG WINAPI WndProc(HWND,UINT,WPARAM,LPARAM);
int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpszCmdLine,int nCmdShow)
{
WNDCLASS wc;
HWND hwnd;
MSG msg;
/***************** 1. Define Windows class **************************/
wc.style = 0; // Class style
wc.lpfnWndProc = (WNDPROC) WndProc; // Window procedure address
wc.cbClsExtra = 0; // Class extra bytes
wc.cbWndExtra = 0; // Window extra bytes
wc.hInstance = hInstance; // Instance handle
wc.hIcon = LoadIcon (NULL, IDI_WINLOGO); // Icon handle
wc.hCursor = LoadCursor (NULL, IDC_ARROW); // Cursor handle
wc.hbrBackground = (HBRUSH) (COLOR_WINDOW + 1); // Background color
wc.lpszMenuName = NULL; // Menu name
wc.lpszClassName = "MyWndClass"; // WNDCLASS name

/***************** 2. Register the Windows class **********************/
RegisterClass(&wc);
/***************** 3. Create window **********************/
hwnd = CreateWindow (
"MyWndClass", // WNDCLASS name
"SDK Application", // Window title
WS_OVERLAPPEDWINDOW, // Window style
CW_USEDEFAULT, // Horizontal position
CW_USEDEFAULT, // Vertical position
CW_USEDEFAULT, // Initial width
CW_USEDEFAULT, // Initial height
HWND_DESKTOP, // Handle of parent window
NULL, // Menu handle
hInstance, // Application's instance handle
NULL // Window-creation data
);

/***************** 4. Display the window **********************/
ShowWindow (hwnd, nCmdShow);
UpdateWindow (hwnd);
/***************** 5. Message loop **********************/
while(GetMessage(&msg,NULL,0,0)){
	TranslateMessage(&msg);
	DispatchMessage(&msg);
}
return msg.wParam;
}
LRESULT CALLBACK WndProc(HWND hwnd, UINT message, WPARAM wParam,LPARAM lParam)
{
PAINTSTRUCT ps;
HDC hdc;
switch(message){
	case WM_PAINT:
	hdc = BeginPaint(hwnd,&ps);
	
	//*************************no.1****************************
	    //*************************no.2****************************
	    Rectangle(hdc, 50, 20,280, 220);
	    Rectangle(hdc, 110, 30,250, 180);
		Rectangle(hdc, 90, 30,230, 170);
		
		Rectangle(hdc, 75, 140,120, 190);
		Rectangle(hdc, 155, 140,200, 190);
	    Rectangle(hdc, 150, 20,170, 40);
	    
	    Rectangle(hdc, 140, 200,160, 220);
	    
	EndPaint(hwnd,&ps);
	return 0;
	case WM_DESTROY:
	PostQuitMessage(0);
	return 0;
}
return DefWindowProc (hwnd, message, wParam, lParam);
}

