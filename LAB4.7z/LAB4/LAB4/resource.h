#define IDR_MYMENU 101
#define IDI_MYICON 201

#define ID_FILE_EXIT 9001
#define ID_FILE_R 9002
#define ID_FILE_G 9003
#define ID_FILE_BL 9004
#define ID_FILE_BK 9005
